//
// Created by honor on 2024/6/11.
//

#ifndef SLAM_H
#define SLAM_H

#include <opencv2/opencv.hpp>
#include <vector>
#include <string>
#include <iostream>

class SLAM {
private:
    cv::Ptr<cv::ORB> detector_;
    cv::Ptr<cv::BFMatcher> matcher_;

    std::vector<cv::DMatch> GetBestMatches(const std::vector<cv::DMatch> &matches) const;

    /**
     * Extract key points.
     * @param prior_image The previous image frame.
     * @param current_image The current image frame.
     * @param prior_image_key_points The key points of the previous image.
     * @param current_image_key_points The key points of the current image.
     * @param best_matches The matching of two image frames' key points.
     */
    void ExtractFeatures(
            const cv::Mat &prior_image,
            const cv::Mat &current_image,
            std::vector<cv::KeyPoint> &prior_image_key_points,
            std::vector<cv::KeyPoint> &current_image_key_points,
            std::vector<cv::DMatch> &best_matches
    ) const;

    /**
     * Recover the posture of camera.
     * @param prior_image_key_points
     * @param current_image_key_points
     * @param best_matches
     * @param K The intrinsic matrix of camera.
     * @param R The rotation matrix of camera.
     * @param t The position vector of camera.
     */
    void RecoverCameraPose(
            const std::vector<cv::KeyPoint> &prior_image_key_points,
            const std::vector<cv::KeyPoint> &current_image_key_points,
            const std::vector<cv::DMatch> &best_matches,
            const cv::Mat &K,
            cv::Mat &R,
            cv::Mat &t
    ) const;

    cv::Point2d Pixel2Camera(const cv::Point2d point_2d, const cv::Mat &K) const;

    /**
     * Estimate the world coordinate of pixels.
     * @param prior_image_key_points
     * @param current_image_key_points
     * @param best_matches
     * @param K
     * @param R
     * @return
     */
    std::vector<cv::Point3f> WorldCoordinateEstimate(
            const std::vector<cv::KeyPoint> &prior_image_key_points,
            const std::vector<cv::KeyPoint> &current_image_key_points,
            const std::vector<cv::DMatch> &best_matches,
            const cv::Mat &K,
            const cv::Mat &R, const cv::Mat &
    ) const;

public:
    SLAM();

    ~SLAM() = default;

    /**
     * The entrance of SLAM.
     * @param prior_image_path
     * @param current_image_path
     */
    void Run(
            const std::string &prior_image_path,
            const std::string &current_image_path
    ) const;
};

#endif //SLAM_H
