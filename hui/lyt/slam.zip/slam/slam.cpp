//
// Created by honor on 2024/6/11.
//

#include "slam.h"

SLAM::SLAM() {
    this->detector_ = cv::ORB::create();
    this->matcher_ = cv::BFMatcher::create(cv::NORM_HAMMING);
}

cv::Point2d SLAM::Pixel2Camera(const cv::Point2d point_2d, const cv::Mat &K) const {
    return cv::Point2d((point_2d.x - K.at<double>(0, 2)) / K.at<double>(0, 0),
                       (point_2d.y - K.at<double>(1, 2)) / K.at<double>(1, 1));
}

std::vector<cv::DMatch> SLAM::GetBestMatches(const std::vector<cv::DMatch> &matches) const {
    std::vector<cv::DMatch> best_matches;

    double min_distance = 0.0;
    for (auto &match: matches) {
        if (min_distance < match.distance) {
            min_distance = match.distance;
        }
    }

    double threshold = std::max(min_distance * 2, 30.0);

    for (auto &match: matches) {
        if (min_distance <= threshold) {
            best_matches.push_back(match);
        }
    }

    return best_matches;
}

void SLAM::ExtractFeatures(
        const cv::Mat &prior_image,
        const cv::Mat &current_image,
        std::vector<cv::KeyPoint> &prior_image_key_points,
        std::vector<cv::KeyPoint> &current_image_key_points,
        std::vector<cv::DMatch> &best_matches
) const {
    detector_->detect(prior_image, prior_image_key_points);
    detector_->detect(current_image, current_image_key_points);

    cv::Mat prior_image_descriptors;
    cv::Mat current_image_descriptors;

    detector_->compute(prior_image, prior_image_key_points, prior_image_descriptors);
    detector_->compute(current_image, current_image_key_points, current_image_descriptors);

    std::vector<cv::DMatch> matches;

    matcher_->match(prior_image_descriptors, current_image_descriptors, matches);

    best_matches = GetBestMatches(matches);
}

void SLAM::RecoverCameraPose(
        const std::vector<cv::KeyPoint> &prior_image_key_points,
        const std::vector<cv::KeyPoint> &current_image_key_points,
        const std::vector<cv::DMatch> &best_matches,
        const cv::Mat &K,
        cv::Mat &R,
        cv::Mat &t
) const {
    std::vector<cv::Point2d> prior_points, current_points;

    for (auto &match: best_matches) {
        prior_points.push_back(prior_image_key_points[match.queryIdx].pt);
        current_points.push_back(current_image_key_points[match.trainIdx].pt);
    }

    auto E = cv::findEssentialMat(prior_points, current_points);

    cv::recoverPose(E, prior_points, current_points, K, R, t, false);
}

std::vector<cv::Point3f> SLAM::WorldCoordinateEstimate(
        const std::vector<cv::KeyPoint> &prior_image_key_points,
        const std::vector<cv::KeyPoint> &current_image_key_points,
        const std::vector<cv::DMatch> &best_matches,
        const cv::Mat &K,
        const cv::Mat &R, const cv::Mat &t
) const {
    cv::Mat P_1 = (cv::Mat_<double>(3, 4) <<
                                          1, 0, 0, 0,
            0, 1, 0, 0,
            0, 0, 1, 0);

    cv::Mat P_2 = (cv::Mat_<double>(3, 4) <<
                                          R.at<double>(0, 0), R.at<double>(0, 0), R.at<double>(0, 0), t.at<double>(0,
                                                                                                                   0),
            R.at<double>(0, 0), R.at<double>(0, 0), R.at<double>(0, 0), t.at<double>(1, 0),
            R.at<double>(0, 0), R.at<double>(0, 0), R.at<double>(0, 0), t.at<double>(2, 0));

    cv::Mat points_4d;
    std::vector<cv::Point2f> points_1, points_2;

    for (auto &match: best_matches) {
        points_1.push_back(Pixel2Camera(prior_image_key_points[match.queryIdx].pt, K));
        points_2.push_back(Pixel2Camera(current_image_key_points[match.trainIdx].pt, K));
    }

    cv::triangulatePoints(P_1, P_2, points_1, points_2, points_4d);

    std::vector<cv::Point3f> coordinates;
    for (int i = 0; i < points_4d.cols; ++i) {
        auto temp = points_4d.col(i);
        temp /= temp.at<float>(3);
        coordinates.push_back(cv::Point3f(temp.at<float>(0), temp.at<float>(1), temp.at<float>(2)));
    }

    return coordinates;
}

void SLAM::Run(const std::string &prior_image_path, const std::string &current_image_path) const {
    cv::Mat prior_image = cv::imread(prior_image_path);
    cv::Mat current_image = cv::imread(current_image_path);

    // The rotation matrix and position vector of camera.
    cv::Mat R, t;

    // The intrinsic matrix of camera.
    cv::Mat K = (cv::Mat_<double>(3, 3) <<
                                        500, 0, 320,
                                        0, 500, 240,
                                        0, 0, 1);

    std::vector<cv::KeyPoint> prior_image_key_points, current_image_key_points;
    std::vector<cv::DMatch> best_matches;

    // Extract the key points from image.
    ExtractFeatures(prior_image, current_image, prior_image_key_points, current_image_key_points, best_matches);

    RecoverCameraPose(prior_image_key_points, current_image_key_points, best_matches, K, R, t);
    auto coordinates = WorldCoordinateEstimate(prior_image_key_points, current_image_key_points, best_matches, K, R, t);
    for (auto &coordinate: coordinates) {
        std::cout << coordinate << std::endl;
    }
}
