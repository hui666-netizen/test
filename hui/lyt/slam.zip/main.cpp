#include "slam/slam.h"

int main() {
    std::string asset_path = "/home/apriloo/workspace/final_work/assets";

    SLAM slam;
    slam.Run(asset_path + "/1.png", asset_path + "/2.png");

    return 0;
}